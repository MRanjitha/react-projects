v0.4.0 - Tue, 31 May 2016 15:56:41 GMT
--------------------------------------

- 


v0.3.1 - Fri, 23 Oct 2015 18:13:08 GMT
--------------------------------------

- [5af856e](../../commit/5af856e) [fixed] Removing ReactDOM from bundle


v0.3.0 - Thu, 22 Oct 2015 06:35:57 GMT
--------------------------------------

- 


# Changelog

### 0.1.0 (Oct 21, 2014)

- Initial release

### 0.2.0 (Jun 11, 2015)

- Allow Disqus thread to unload and load a new one
- Moving React to `peerDependencies`
- Updating to React 0.13
- Removing JSX

### 0.2.1 (Jun 11, 2015)

- Fixing issue with deprecated `transferPropsTo`

### 0.2.2 (Jun 11, 2015)

- Adding React to `devDependencies`
