module.exports = {
  setupFiles: ['<rootDir>/jest/shim.js', '<rootDir>/jest/setup.js']
};
