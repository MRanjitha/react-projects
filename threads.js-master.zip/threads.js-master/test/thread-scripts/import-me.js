self.importedEcho = function(input, done) {
  done(input);
};
