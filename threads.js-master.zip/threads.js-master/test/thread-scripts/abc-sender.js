module.exports = function(param, done) {
  done('abc');
};
