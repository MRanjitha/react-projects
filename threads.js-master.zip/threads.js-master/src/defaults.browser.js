/*eslint-env browser*/

export default {
  pool : {
    size : navigator.hardwareConcurrency || 8
  }
};
